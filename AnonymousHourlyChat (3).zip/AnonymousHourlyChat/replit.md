# Anoion - Anonymous Chatroom Architecture

## Overview

Anoion (pronounced ah-nah-ee-on) is a fully anonymous chatroom that purges itself every hour, built with a modern full-stack architecture. The application features a React frontend with TypeScript, an Express.js backend with WebSocket support, and uses Drizzle ORM with PostgreSQL for data persistence. The app includes real-time messaging, theme switching, automatic hourly resets, and zero-log privacy.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Pages**: Chat interface (/) and About page (/about)

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Real-time Communication**: WebSocket Server (ws library)
- **API Architecture**: RESTful endpoints with WebSocket for real-time features
- **Development**: tsx for TypeScript execution in development

### Data Storage
- **Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM with type-safe queries
- **Schema**: Two main tables - users and messages
- **Migrations**: Drizzle Kit for database schema management
- **Fallback Storage**: In-memory storage implementation for development

## Key Components

### Database Schema
- **Users Table**: id (serial), username (unique), password
- **Messages Table**: id (serial), username, content, timestamp
- Type-safe schemas generated with drizzle-zod integration

### Real-time Features
- WebSocket connection on `/ws` path
- Real-time message broadcasting to all connected clients
- Connection management with automatic cleanup
- Message persistence with immediate broadcast

### Theme System
- Multiple built-in themes (dark purple default, light, blue, green, orange)
- CSS variables for dynamic theme switching
- Local storage persistence for theme preferences
- Avatar color generation based on username
- Smooth transitions between themes

### Auto-reset Functionality
- Hourly automatic reset of all messages and usernames
- Broadcast notifications to all connected clients
- Automatic scheduling for next reset cycle

## Data Flow

### Message Flow
1. User enters message in frontend input
2. Message sent via WebSocket to backend
3. Backend validates and stores message in database
4. Backend broadcasts message to all connected WebSocket clients
5. All clients receive and display the new message in real-time

### User Management
- Simple username-based identification (no authentication)
- Username uniqueness validation
- Avatar color assignment based on username hash
- Username clearing during hourly resets
- Zero-log privacy - no user data stored

### About Page
- Information about Anoion pronunciation and purpose
- Feature highlights (zero-log privacy, auto-purge, anonymous)
- Community guidelines
- Navigation between chat and about pages

### Theme Management
- Client-side theme selection and persistence
- CSS variable updates for instant theme switching
- Theme state maintained in localStorage

## External Dependencies

### Core Framework Dependencies
- React ecosystem (react, react-dom, @vitejs/plugin-react)
- Express.js with WebSocket support (ws library)
- Drizzle ORM with PostgreSQL adapter (@neondatabase/serverless)

### UI and Styling
- Radix UI primitives for accessible components
- Tailwind CSS for utility-first styling
- Lucide React for consistent iconography
- class-variance-authority for component variants

### Development Tools
- TypeScript for type safety
- Vite for development server and builds
- tsx for TypeScript execution
- Replit-specific plugins for development environment

## Deployment Strategy

### Build Process
- Frontend: Vite builds optimized static assets to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Single build command creates both frontend and backend distributions

### Environment Configuration
- DATABASE_URL environment variable for PostgreSQL connection
- Development vs production mode detection
- Automatic database provisioning check

### Hosting Requirements
- Node.js runtime environment
- PostgreSQL database (Neon Database recommended)
- WebSocket support for real-time features
- Static file serving for frontend assets

### Development Workflow
- `npm run dev` - Starts development server with hot reloading
- `npm run build` - Creates production builds
- `npm run start` - Runs production server
- `npm run db:push` - Pushes schema changes to database

The application is designed to be easily deployable on platforms like Replit, Vercel, or similar hosting services that support full-stack applications with WebSocket capabilities.