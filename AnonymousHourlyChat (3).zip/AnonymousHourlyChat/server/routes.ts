import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";

interface WebSocketClient extends WebSocket {
  id: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store connected clients
  const clients = new Set<WebSocketClient>();

  // Broadcast message to all connected clients
  function broadcast(message: any) {
    const messageStr = JSON.stringify(message);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  // Hourly reset functionality
  let resetInterval: NodeJS.Timeout;
  
  function scheduleNextReset() {
    const now = new Date();
    const nextHour = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + 1, 0, 0, 0);
    const msUntilNextHour = nextHour.getTime() - now.getTime();
    
    if (resetInterval) {
      clearTimeout(resetInterval);
    }
    
    resetInterval = setTimeout(async () => {
      // Clear all messages and usernames
      await storage.clearAllMessages();
      await storage.clearAllUsernames();
      
      // Broadcast reset notification to all clients
      broadcast({
        type: 'chat_reset',
        timestamp: new Date().toISOString()
      });
      
      // Schedule next reset
      scheduleNextReset();
    }, msUntilNextHour);
  }

  // Start the reset scheduler
  scheduleNextReset();

  wss.on('connection', (ws: WebSocketClient) => {
    ws.id = Math.random().toString(36).substring(2, 15);
    clients.add(ws);

    // Send initial messages to new client
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'get_messages') {
          const messages = await storage.getAllMessages();
          ws.send(JSON.stringify({
            type: 'initial_messages',
            messages
          }));
        } else if (message.type === 'send_message') {
          // Validate message data
          const validatedMessage = insertMessageSchema.parse({
            username: message.username,
            content: message.content
          });
          
          // Check if username is taken
          const usernameExists = await storage.checkUsernameExists(validatedMessage.username);
          if (!usernameExists) {
            // Save message
            const savedMessage = await storage.createMessage(validatedMessage);
            
            // Broadcast to all clients
            broadcast({
              type: 'new_message',
              message: savedMessage
            });
          } else {
            // Send error if username is already taken
            ws.send(JSON.stringify({
              type: 'error',
              message: 'Username already taken'
            }));
          }
        } else if (message.type === 'check_username') {
          const exists = await storage.checkUsernameExists(message.username);
          ws.send(JSON.stringify({
            type: 'username_check_result',
            username: message.username,
            exists
          }));
        }
      } catch (error) {
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
    });
  });

  // REST API endpoints
  app.get('/api/messages', async (req, res) => {
    try {
      const messages = await storage.getAllMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  app.post('/api/messages', async (req, res) => {
    try {
      const validatedMessage = insertMessageSchema.parse(req.body);
      const savedMessage = await storage.createMessage(validatedMessage);
      res.json(savedMessage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid message format' });
      } else {
        res.status(500).json({ error: 'Failed to create message' });
      }
    }
  });

  app.get('/api/usernames', async (req, res) => {
    try {
      const usernames = await storage.getAllUsernames();
      res.json(usernames);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch usernames' });
    }
  });

  return httpServer;
}
