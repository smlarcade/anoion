import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Shield, Clock, MessageCircle } from "lucide-react";
import { Link } from "wouter";

export default function About() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Chat
              </Button>
            </Link>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">About Anoion</h1>
                <p className="text-sm text-muted-foreground">Learn more about our anonymous chatroom</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Main Description */}
          <Card className="p-6">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-foreground">What is Anoion?</h2>
              <p className="text-lg text-foreground leading-relaxed">
                Anoion (pronounced <span className="font-semibold">ah-nah-ee-on</span>) is a fully anonymous chatroom that purges itself every hour or every five minutes. Anoion makes it so you can send messages privately with a zero-log privacy, so you dont have to worry about feds knocking on your door because you admitted to tax fraud.. ahem, anyway just dont do illegial shit and have fun!
              </p>
            </div>
          </Card>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Zero-Log Privacy</h3>
                <p className="text-sm text-muted-foreground">
                  No data stored, no tracking, no logs. Your messages exist only in the moment.
                </p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Auto-Purge</h3>
                <p className="text-sm text-muted-foreground">
                  Chat history automatically clears every hour, ensuring fresh conversations.
                </p>
              </div>
            </Card>

            <Card className="p-6">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Anonymous</h3>
                <p className="text-sm text-muted-foreground">
                  No accounts, no sign-ups. Just pick a temporary username and start chatting.
                </p>
              </div>
            </Card>
          </div>

          {/* Guidelines */}
          <Card className="p-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-foreground">Community Guidelines</h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>• Be respectful to other users</p>
                <p>• Don't share personal information</p>
                <p>• No illegal activities or content</p>
                <p>• Have fun and enjoy the conversation!</p>
              </div>
            </div>
          </Card>

          {/* Call to Action */}
          <div className="text-center py-8">
            <Link href="/">
              <Button size="lg" className="text-lg px-8">
                Start Chatting
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}