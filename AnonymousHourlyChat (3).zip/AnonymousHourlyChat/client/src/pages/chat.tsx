import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MessageCircle, Palette, ChevronDown, Info, HelpCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import type { Message } from "@shared/schema";

const themes = [
  { id: 'dark', name: 'Dark Purple', color: 'bg-purple-500' },
  { id: 'light', name: 'Light', color: 'bg-gray-200' },
  { id: 'blue', name: 'Ocean Blue', color: 'bg-blue-500' },
  { id: 'green', name: 'Forest Green', color: 'bg-green-500' },
  { id: 'orange', name: 'Sunset Orange', color: 'bg-orange-500' },
];

const avatarColors = [
  'bg-purple-500',
  'bg-blue-500', 
  'bg-green-500',
  'bg-red-500',
  'bg-yellow-500',
  'bg-pink-500',
  'bg-indigo-500',
  'bg-teal-500',
];

function getAvatarColor(username: string): string {
  const index = username.length % avatarColors.length;
  return avatarColors[index];
}

function formatTimeAgo(timestamp: Date): string {
  const now = new Date();
  const diff = now.getTime() - new Date(timestamp).getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (seconds < 60) return 'now';
  if (minutes < 60) return `${minutes} min ago`;
  if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  return new Date(timestamp).toLocaleDateString();
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [username, setUsername] = useState('');
  const [currentUsername, setCurrentUsername] = useState('');
  const [messageInput, setMessageInput] = useState('');
  const [theme, setTheme] = useState('dark');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [resetTimer, setResetTimer] = useState({ minutes: 0, seconds: 0 });
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Load saved theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('chatroom-theme') || 'dark';
    setTheme(savedTheme);
    document.documentElement.setAttribute('data-theme', savedTheme);
  }, []);

  // Connect to WebSocket
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      setIsConnected(true);
      setSocket(ws);
      // Request initial messages
      ws.send(JSON.stringify({ type: 'get_messages' }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'initial_messages') {
        setMessages(data.messages);
      } else if (data.type === 'new_message') {
        setMessages(prev => [...prev, data.message]);
      } else if (data.type === 'chat_reset') {
        setMessages([]);
        setCurrentUsername('');
        toast({
          title: "Chat Reset",
          description: "The chat has been reset for a new hour!",
        });
      } else if (data.type === 'error') {
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive",
        });
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      setSocket(null);
    };

    return () => {
      ws.close();
    };
  }, [toast]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Update reset timer
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const nextHour = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + 1, 0, 0, 0);
      const diff = nextHour.getTime() - now.getTime();
      
      const minutes = Math.floor(diff / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      
      setResetTimer({ minutes, seconds });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('chatroom-theme', newTheme);
    setDropdownOpen(false);
  };

  const handleSetUsername = () => {
    const trimmedUsername = username.trim();
    if (trimmedUsername && trimmedUsername.length >= 2) {
      setCurrentUsername(trimmedUsername);
      setUsername('');
    }
  };

  const handleSendMessage = () => {
    if (messageInput.trim() && currentUsername && socket && isConnected) {
      socket.send(JSON.stringify({
        type: 'send_message',
        username: currentUsername,
        content: messageInput.trim()
      }));
      setMessageInput('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent, action: () => void) => {
    if (e.key === 'Enter') {
      action();
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Anoion</h1>
                <p className="text-sm text-muted-foreground">Resets every hour</p>
              </div>
            </div>
            
            {/* Navigation and Theme Selector */}
            <div className="flex items-center space-x-3">
              <Link href="/about">
                <Button variant="ghost" size="sm">
                  <HelpCircle className="w-4 h-4 mr-2" />
                  About
                </Button>
              </Link>
              
              <div className="relative">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center space-x-2"
              >
                <Palette className="w-4 h-4" />
                <span>Theme</span>
                <ChevronDown className="w-4 h-4" />
              </Button>
              
              {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-lg shadow-lg">
                  <div className="py-2">
                    {themes.map((themeOption) => (
                      <button
                        key={themeOption.id}
                        onClick={() => handleThemeChange(themeOption.id)}
                        className="w-full text-left px-4 py-2 text-sm text-foreground hover:bg-accent hover:text-accent-foreground flex items-center space-x-3"
                      >
                        <div className={`w-4 h-4 rounded-full ${themeOption.color}`}></div>
                        <span>{themeOption.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            </div>
          </div>
          
          {/* Reset Timer */}
          <div className="mt-3 flex items-center justify-center">
            <Card className="px-3 py-2">
              <div className="flex items-center space-x-2 text-sm">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                <span className="text-muted-foreground">Next reset in: </span>
                <span className="text-foreground font-mono">
                  {resetTimer.minutes.toString().padStart(2, '0')}:{resetTimer.seconds.toString().padStart(2, '0')}
                </span>
              </div>
            </Card>
          </div>
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="max-w-4xl mx-auto px-4">
        <div className="h-[calc(100vh-280px)] overflow-y-auto py-4">
          <div className="space-y-4">
            {/* System Message */}
            <div className="flex justify-center">
              <Card className="px-4 py-2">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Info className="w-4 h-4" />
                  <span>Welcome to the anonymous chatroom. Messages reset every hour.</span>
                </div>
              </Card>
            </div>

            {/* Messages */}
            {messages.map((message) => (
              <div key={message.id} className="animate-in slide-in-from-bottom-2">
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 rounded-full ${getAvatarColor(message.username)} flex items-center justify-center text-white text-sm font-medium`}>
                    {message.username.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-sm font-medium text-foreground">{message.username}</span>
                      <span className="text-xs text-muted-foreground">{formatTimeAgo(message.timestamp)}</span>
                    </div>
                    <Card className="px-4 py-2">
                      <p className="text-foreground">{message.content}</p>
                    </Card>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </main>

      {/* Bottom Input Area */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
        <div className="max-w-4xl mx-auto px-4 py-4">
          {!currentUsername ? (
            /* Username Setup */
            <div className="space-y-3">
              <div className="flex space-x-3">
                <Input
                  type="text"
                  placeholder="Enter your anonymous username..."
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onKeyPress={(e) => handleKeyPress(e, handleSetUsername)}
                  maxLength={20}
                  className="flex-1"
                />
                <Button onClick={handleSetUsername} disabled={!username.trim() || username.trim().length < 2}>
                  Join Chat
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Choose a temporary username for this session</p>
            </div>
          ) : (
            /* Message Input */
            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full ${getAvatarColor(currentUsername)} flex items-center justify-center text-white text-sm font-medium`}>
                  {currentUsername.charAt(0).toUpperCase()}
                </div>
                <Input
                  type="text"
                  placeholder="Type your message..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={(e) => handleKeyPress(e, handleSendMessage)}
                  maxLength={500}
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} disabled={!messageInput.trim() || !isConnected}>
                  Send
                </Button>
              </div>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Logged in as: <span className="text-foreground font-medium">{currentUsername}</span></span>
                <button
                  onClick={() => setCurrentUsername('')}
                  className="hover:text-foreground rounded px-2 py-1"
                >
                  Change Username
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
